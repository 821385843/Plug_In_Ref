//
//  PiaoJin.h
//  PiaoJinDylib
//
//  Created by 谢伟 on 2018/11/5.
//  Copyright © 2018 谢伟. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface PiaoJin : NSObject

- (void)love;

@end

NS_ASSUME_NONNULL_END
