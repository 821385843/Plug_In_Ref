//
//  PiaoJinDylib.h
//  PiaoJinDylib
//
//  Created by 谢伟 on 2018/11/5.
//  Copyright © 2018 谢伟. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for PiaoJinDylib.
FOUNDATION_EXPORT double PiaoJinDylibVersionNumber;

//! Project version string for PiaoJinDylib.
FOUNDATION_EXPORT const unsigned char PiaoJinDylibVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PiaoJinDylib/PublicHeader.h>

#import "PiaoJin.h"


